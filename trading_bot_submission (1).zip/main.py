import argparse
from basic_bot import BasicBot

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--api_key", required=True)
    parser.add_argument("--api_secret", required=True)
    parser.add_argument("--symbol", default="BTCUSDT")
    parser.add_argument("--side", choices=["BUY", "SELL"], required=True)
    parser.add_argument("--type", choices=["MARKET", "LIMIT"], required=True)
    parser.add_argument("--quantity", type=float, required=True)
    parser.add_argument("--price", type=float, help="Required if type is LIMIT")

    args = parser.parse_args()
    bot = BasicBot(args.api_key, args.api_secret)

    order = bot.place_order(
        symbol=args.symbol,
        side=args.side,
        order_type=args.type,
        quantity=args.quantity,
        price=args.price
    )

    if order:
        print("Order placed successfully.")
        print(order)

if __name__ == "__main__":
    main()