# Simplified Binance Futures Trading Bot

## Overview
This Python bot allows you to place market and limit orders on Binance Futures Testnet using the official Binance API.

## Requirements
- Python 3.x
- python-binance

## Setup
```bash
pip install python-binance
```

## Usage
```bash
python main.py --api_key <API_KEY> --api_secret <API_SECRET> --side BUY --type MARKET --quantity 0.001
```

## Files
- `basic_bot.py`: Core trading logic
- `main.py`: Command-line interface
- `bot.log`: Log file for order tracking

## Author
Assignment for "Junior Python Developer – Crypto Trading Bot"