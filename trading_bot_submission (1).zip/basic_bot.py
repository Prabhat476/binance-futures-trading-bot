from binance.client import Client
import logging

class BasicBot:
    def __init__(self, api_key, api_secret, testnet=True):
        self.api_key = api_key
        self.api_secret = api_secret
        self.client = Client(api_key, api_secret, testnet=testnet)
        if testnet:
            self.client.FUTURES_URL = 'https://testnet.binancefuture.com/fapi'
        logging.basicConfig(filename='bot.log', level=logging.INFO)

    def place_order(self, symbol, side, order_type, quantity, price=None):
        try:
            if order_type == "MARKET":
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type="MARKET",
                    quantity=quantity
                )
            elif order_type == "LIMIT" and price:
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type="LIMIT",
                    quantity=quantity,
                    timeInForce="GTC",
                    price=price
                )
            else:
                raise ValueError("Invalid order type or missing price for limit order")

            logging.info(f"Order placed: {order}")
            return order
        except Exception as e:
            logging.error(f"Order failed: {e}")
            print("Error:", e)
            return None